Auto Clicker v1.0
=================

A simple, fast, and free Auto Clicker for Windows.

Features:
-   Variable Click Intervals (Milliseconds)
-   Left or Right mouse button
-   Click at current cursor or fixed location
-   Background Themes (Dark, Matrix, Space, etc.)
-   Global Hotkey: F6 to Start/Stop

Installation:
-------------
No installation required! Just extract this folder and run "AutoClicker.exe".

Troubleshooting:
----------------
If the app doesn't start, make sure you have extracted all files from the zip.
